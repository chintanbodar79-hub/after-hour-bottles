import { Order, User } from '../types';

export const sendOrderConfirmationEmail = (order: Order, user: User) => {
  const itemsList = order.items.map(item => `- ${item.name} x${item.quantity} ($${(item.price * item.quantity).toFixed(2)})`).join('\n    ');
  
  const body = `
    Hi ${user.name},

    Thank you for your order with After Hour Bottles!

    ORDER DETAILS
    ------------------------------------------------------
    Order ID: ${order.id}
    Date: ${new Date(order.date).toLocaleString()}
    Payment Method: ${order.paymentMethod}
    
    Delivery Address:
    ${order.customerAddress || 'Pickup'}
    ${order.deliveryInstructions ? `Instructions: ${order.deliveryInstructions}` : ''}

    ITEMS
    ------------------------------------------------------
    ${itemsList}

    ------------------------------------------------------
    TOTAL: $${order.total.toFixed(2)}
    ------------------------------------------------------

    Estimated Delivery Time: 15-20 minutes.
    
    You can track your order status live here: 
    ${window.location.origin}/#/track/${order.id}

    Cheers,
    The After Hour Bottles Team
  `;

  console.group(`📧 SIMULATING EMAIL TO: ${user.email}`);
  console.log(`Subject: Order Confirmation #${order.id}`);
  console.log(body);
  console.groupEnd();

  // Alert for demo visibility
  setTimeout(() => {
    alert(`Confirmation email sent to ${user.email}!\n(Check console for details)`);
  }, 1000);
};

export const sendPasswordResetEmail = (email: string) => {
  console.group(`📧 SIMULATING PASSWORD RESET TO: ${email}`);
  console.log("Subject: Password Reset Request");
  console.log(`Body: We received a request to reset your password.`);
  console.log(`Link: ${window.location.origin}/#/reset-password?token=simulated_token_123`);
  console.groupEnd();

  setTimeout(() => {
    alert(`Password reset link sent to ${email}`);
  }, 500);
};