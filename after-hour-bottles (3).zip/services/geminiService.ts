import { GoogleGenAI } from "@google/genai";
import { GroundingChunk } from "../types";

// Helper to get AI instance safely
const getAiClient = () => {
  if (!process.env.API_KEY) {
    console.warn("API_KEY is missing from environment variables.");
    return null;
  }
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

/**
 * Checks if an address is valid and within a hypothetical delivery zone using Google Maps Grounding.
 * Note: Since this is a demo, we use the model to reasoning about the location relative to "Milwaukee, WI"
 * (based on the 414 area code in the image).
 */
export const checkDeliveryLocation = async (address: string): Promise<{
  allowed: boolean;
  message: string;
  sources: GroundingChunk[];
}> => {
  const ai = getAiClient();
  if (!ai) return { allowed: false, message: "AI Service Unavailable", sources: [] };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `I need to check if the following address is a real place near Milwaukee, WI (within 20 miles). Address: "${address}". 
      If it is a valid location within range, say "YES". If it is too far or invalid, say "NO". 
      Then provide a very brief 1 sentence description of the location.`,
      config: {
        tools: [{ googleMaps: {} }],
      },
    });

    const text = response.text || "";
    const isAllowed = text.includes("YES");
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] || [];

    return {
      allowed: isAllowed,
      message: text.replace("YES", "").replace("NO", "").trim(),
      sources: chunks
    };
  } catch (error) {
    console.error("Gemini Maps Error:", error);
    return { allowed: false, message: "Could not verify location at this time.", sources: [] };
  }
};

/**
 * Uses Google Search Grounding to get details about a specific liquor.
 */
export const getProductDetails = async (productName: string): Promise<{
  details: string;
  sources: GroundingChunk[];
}> => {
  const ai = getAiClient();
  if (!ai) return { details: "AI Service Unavailable", sources: [] };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `What kind of liquor is "${productName}"? What does it taste like and what is the alcohol percentage? Keep it short (2 sentences).`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    return {
      details: response.text || "No details available.",
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] || []
    };
  } catch (error) {
    console.error("Gemini Search Error:", error);
    return { details: "Could not fetch product details.", sources: [] };
  }
};