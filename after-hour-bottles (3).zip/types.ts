export enum Category {
  PINT = 'Pint',
  FIFTH = 'Fifth',
  HALF_PINT = 'Half Pint',
  COCKTAIL_BAGS = 'Cocktail Bags'
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: Category;
  image: string;
  description?: string;
  stock: number;
  promo?: {
    buyQuantity: number;
    price: number; // Price for the bundle (e.g., 35 for 2)
    label: string;
  };
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'Pending' | 'Accepted' | 'Delivering' | 'Completed';
  date: string;
  customerAddress?: string;
  deliveryMethod?: 'Delivery' | 'Pickup';
  deliveryInstructions?: string;
  paymentMethod?: string;
  estimatedDeliveryTime?: string; // e.g. "15-20 mins"
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'customer';
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
  maps?: {
    uri: string;
    title: string;
    placeAnswerSources?: {
        reviewSnippets?: {
            snippet?: string;
        }[]
    }[]
  };
}