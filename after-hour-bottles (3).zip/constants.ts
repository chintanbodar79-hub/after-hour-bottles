import { Product, Category } from './types';

export const DELIVERY_FEE = 5;
export const PHONE_NUMBER = "414-882-3064";

export const PRODUCTS: Product[] = [
  // PINT
  { 
    id: 'p1', 
    name: 'Bacardi', 
    price: 20, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1618172193763-c511deb635ca?q=80&w=600&auto=format&fit=crop', // White Rum
    stock: 3, // Low Stock
    promo: { buyQuantity: 2, price: 35, label: "2 for $35" }
  },
  { 
    id: 'p2', 
    name: "Jose/Tito's", 
    price: 20, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1592317376783-02f884f23b24?q=80&w=600&auto=format&fit=crop', // Vodka
    stock: 15,
    promo: { buyQuantity: 2, price: 35, label: "2 for $35" }
  },
  { 
    id: 'p3', 
    name: 'Pink Whitney', 
    price: 20, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1602052577122-f73b9710f972?q=80&w=600&auto=format&fit=crop', // Pink Liquor/Bottle
    stock: 2, // Critical Stock
    promo: { buyQuantity: 2, price: 35, label: "2 for $35" }
  },
  { 
    id: 'p4', 
    name: 'Milagro', 
    price: 30, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1516535794938-606387ce5601?q=80&w=600&auto=format&fit=crop', // Blue Tequila Bottle
    stock: 10
  },
  { 
    id: 'p5', 
    name: 'Crown Royal', 
    price: 35, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?q=80&w=600&auto=format&fit=crop', // Whiskey
    stock: 8
  },
  { 
    id: 'p6', 
    name: 'Paul Masson', 
    price: 20, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1569529465841-dfecdab7503b?q=80&w=600&auto=format&fit=crop', // Brandy/Cognac
    stock: 0, // Out of Stock
    promo: { buyQuantity: 2, price: 35, label: "2 for $35" }
  },
  { 
    id: 'p7', 
    name: 'Lunazul', 
    price: 20, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?q=80&w=600&auto=format&fit=crop', // Tequila
    stock: 12,
    promo: { buyQuantity: 2, price: 35, label: "2 for $35" }
  },
  { 
    id: 'p8', 
    name: 'Hennessy', 
    price: 40, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1613208602569-8a483324c478?q=80&w=600&auto=format&fit=crop', // Hennessy
    stock: 5
  },
  { 
    id: 'p9', 
    name: 'Casamigos White', 
    price: 45, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1588612501258-c91845eb5c9c?q=80&w=600&auto=format&fit=crop', // Tequila
    stock: 7
  },
  { 
    id: 'p10', 
    name: 'Don Julio', 
    price: 45, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?q=80&w=600&auto=format&fit=crop', // Don Julio shape
    stock: 6
  },
  { 
    id: 'p11', 
    name: 'Dusse', 
    price: 45, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1572915645703-912f2c25605d?q=80&w=600&auto=format&fit=crop', // Cognac
    stock: 4 // Low Stock
  },
  { 
    id: 'p12', 
    name: 'Patron', 
    price: 45, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1596700877983-a7c87c25eb7b?q=80&w=600&auto=format&fit=crop', // Patron Bottle
    stock: 10
  },
  { 
    id: 'p13', 
    name: 'Remy', 
    price: 45, 
    category: Category.PINT,
    image: 'https://images.unsplash.com/photo-1569529465841-dfecdab7503b?q=80&w=600&auto=format&fit=crop', // Cognac
    stock: 8
  },

  // FIFTH
  { 
    id: 'f1', 
    name: 'Taylor Port', 
    price: 25, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=600&auto=format&fit=crop', // Red Wine
    stock: 20
  },
  { 
    id: 'f2', 
    name: "Bacardi/Jose/Titos", 
    price: 35, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1606756828574-d4508d5df726?q=80&w=600&auto=format&fit=crop', // Vodka
    stock: 18
  },
  { 
    id: 'f3', 
    name: 'Lunazul', 
    price: 35, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?q=80&w=600&auto=format&fit=crop',
    stock: 11
  },
  { 
    id: 'f4', 
    name: 'Paul Masson', 
    price: 35, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1613208602569-8a483324c478?q=80&w=600&auto=format&fit=crop',
    stock: 0 // Out of Stock
  },
  { 
    id: 'f5', 
    name: '1800', 
    price: 55, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1516535794938-606387ce5601?q=80&w=600&auto=format&fit=crop',
    stock: 5
  },
  { 
    id: 'f6', 
    name: 'Crown Royal', 
    price: 65, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1595981267035-7b04ca84a82d?q=80&w=600&auto=format&fit=crop',
    stock: 7
  },
  { 
    id: 'f7', 
    name: 'Hennessy', 
    price: 70, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1613208602569-8a483324c478?q=80&w=600&auto=format&fit=crop',
    stock: 6
  },
  { 
    id: 'f8', 
    name: 'Don Julio', 
    price: 85, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?q=80&w=600&auto=format&fit=crop',
    stock: 3 // Low Stock
  },
  { 
    id: 'f9', 
    name: "D'usse/Remy", 
    price: 85, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1572915645703-912f2c25605d?q=80&w=600&auto=format&fit=crop',
    stock: 4
  },
  { 
    id: 'f10', 
    name: 'Casamigos/Patron', 
    price: 85, 
    category: Category.FIFTH,
    image: 'https://images.unsplash.com/photo-1588612501258-c91845eb5c9c?q=80&w=600&auto=format&fit=crop',
    stock: 9
  },

  // HALF PINT
  { 
    id: 'hp1', 
    name: "Hennessy/D'usse/Remy", 
    price: 30, 
    category: Category.HALF_PINT,
    image: 'https://images.unsplash.com/photo-1613208602569-8a483324c478?q=80&w=600&auto=format&fit=crop',
    stock: 25
  },

  // COCKTAIL BAGS
  { 
    id: 'cb1', 
    name: 'Beatbox', 
    price: 20, 
    category: Category.COCKTAIL_BAGS,
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=600&auto=format&fit=crop', // Colorful cocktail
    stock: 50,
    promo: { buyQuantity: 2, price: 35, label: "2 for $35" }
  },
  { 
    id: 'cb2', 
    name: 'Lunazul Bag', 
    price: 30, 
    category: Category.COCKTAIL_BAGS,
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?q=80&w=600&auto=format&fit=crop', // Party drink
    stock: 1
  },
];