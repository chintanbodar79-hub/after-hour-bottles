import React, { useState, useEffect, useMemo, useRef } from 'react';
import { HashRouter, Routes, Route, Link, useLocation, Navigate, useNavigate, useParams } from 'react-router-dom';
import { PRODUCTS, DELIVERY_FEE, PHONE_NUMBER } from './constants';
import { Product, CartItem, Category, Order, GroundingChunk, User } from './types';
import { checkDeliveryLocation, getProductDetails } from './services/geminiService';
import { sendOrderConfirmationEmail, sendPasswordResetEmail } from './services/emailService';
import { 
  ShoppingCart, 
  MapPin, 
  Search, 
  Menu, 
  X, 
  Phone, 
  CreditCard, 
  TrendingUp, 
  Package, 
  Info,
  ExternalLink,
  User as UserIcon,
  LogOut,
  LogIn,
  Lock,
  Store,
  Truck,
  CheckCircle,
  Clock,
  Smartphone,
  DollarSign,
  ChevronRight,
  AlertTriangle,
  Minus,
  Plus,
  Calendar,
  ChevronDown,
  ChevronUp,
  History,
  KeyRound,
  ArrowLeft,
  Tag,
  FileText,
  LayoutDashboard,
  ClipboardList,
  ArrowUpDown,
  RotateCcw,
  Navigation,
  CheckSquare,
  PieChart,
  Bell,
  Map,
  PlusCircle,
  Percent,
  Banknote,
  Cross,
  Github,
  Cloud,
  Database
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Global Leaflet definition since we are loading via CDN
declare global {
  interface Window {
    L: any;
  }
}

// --- HELPERS ---

const calculateItemTotal = (item: CartItem): number => {
    if (item.promo && item.quantity >= item.promo.buyQuantity) {
        const bundles = Math.floor(item.quantity / item.promo.buyQuantity);
        const remainder = item.quantity % item.promo.buyQuantity;
        return (bundles * item.promo.price) + (remainder * item.price);
    }
    return item.quantity * item.price;
};

const sendNotification = (recipient: 'Customer' | 'Admin', message: string) => {
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 z-[100] p-4 rounded-lg shadow-2xl flex items-center gap-3 animate-slide-in ${recipient === 'Admin' ? 'bg-zinc-800 border border-brand-accent text-white' : 'bg-brand-success text-black'}`;
    toast.innerHTML = `
        <div class="p-2 bg-white/10 rounded-full"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg></div>
        <div>
            <p class="text-xs font-bold uppercase opacity-75">${recipient} Alert</p>
            <p class="font-medium text-sm">${message}</p>
        </div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 500);
    }, 4000);
};

// --- MAP COMPONENT ---
// Interactive map using Leaflet
const MapComponent = ({ userLocation, driverLocation, showZone = true, height = "400px" }: any) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const leafletMap = useRef<any>(null);
  const markers = useRef<any>({});

  // Center of Milwaukee
  const MILWAUKEE_CENTER = [43.0389, -87.9065];

  useEffect(() => {
    if (mapRef.current && !leafletMap.current && window.L) {
      // Initialize Map
      leafletMap.current = window.L.map(mapRef.current, {
        center: MILWAUKEE_CENTER,
        zoom: 11,
        zoomControl: false,
        attributionControl: false
      });

      // Dark Mode Tiles (CartoDB Dark Matter)
      window.L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        subdomains: 'abcd',
        maxZoom: 19
      }).addTo(leafletMap.current);

      // Add Delivery Zone Circle (20 miles ~= 32186 meters)
      if (showZone) {
         window.L.circle(MILWAUKEE_CENTER, {
            color: '#a855f7', // brand-accent
            fillColor: '#a855f7',
            fillOpacity: 0.08,
            radius: 32186,
            weight: 1,
            dashArray: '5, 10'
         }).addTo(leafletMap.current);
         
         // Store Label
         const storeIcon = window.L.divIcon({
             className: 'bg-transparent',
             html: `<div class="flex flex-col items-center"><div class="p-2 bg-brand-dark border-2 border-brand-accent rounded-full text-brand-accent shadow-[0_0_15px_rgba(168,85,247,0.5)]"><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2v0a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12v0a2 2 0 0 1-2-2V7"/></svg></div><span class="text-[10px] font-bold text-brand-accent mt-1 bg-black/50 px-1 rounded">HQ</span></div>`
         });
         window.L.marker(MILWAUKEE_CENTER, { icon: storeIcon }).addTo(leafletMap.current);
      }
    }
  }, []);

  // Handle Updates
  useEffect(() => {
     if (!leafletMap.current || !window.L) return;

     // User Location Marker
     if (userLocation) {
         if (!markers.current.user) {
             const icon = window.L.divIcon({
                 className: 'bg-transparent',
                 html: `<div class="relative"><div class="w-4 h-4 bg-brand-success rounded-full border-2 border-white shadow-[0_0_15px_rgba(34,197,94,1)]"></div><div class="absolute -inset-2 bg-brand-success/30 rounded-full animate-ping"></div></div>`
             });
             markers.current.user = window.L.marker(userLocation, { icon }).addTo(leafletMap.current)
                .bindPopup("<b>Your Location</b><br>Inside Delivery Zone", { closeButton: false });
             
             markers.current.user.openPopup();
             leafletMap.current.setView(userLocation, 12, { animate: true });
         } else {
             markers.current.user.setLatLng(userLocation);
         }
     }

     // Driver Location Marker
     if (driverLocation) {
         if (!markers.current.driver) {
             const icon = window.L.divIcon({
                 className: 'bg-transparent',
                 html: `<div class="p-2 bg-brand-accent rounded-full text-white shadow-[0_0_20px_rgba(168,85,247,0.8)] z-50 transform transition-transform duration-500"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 17h4V5H2v12h3"/><path d="M20 17h2v-3.34a4 4 0 0 0-1.17-2.83L19 9h-5"/><path d="M14 17h1"/><circle cx="7.5" cy="17.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg></div>`
             });
             markers.current.driver = window.L.marker(driverLocation, { icon }).addTo(leafletMap.current)
                .bindPopup("<b>Driver</b><br>On the way", { closeButton: false });
             
             markers.current.driver.openPopup();
         } else {
             markers.current.driver.setLatLng(driverLocation);
             // markers.current.driver.update();
         }
     }
  }, [userLocation, driverLocation]);

  return <div ref={mapRef} style={{ height }} className="w-full rounded-xl overflow-hidden border border-white/10 shadow-inner bg-zinc-900" />;
};


// --- EXISTING COMPONENTS (Navbar, ProductCard, etc.) ---

const Navbar = ({ cartCount, toggleCart, mobileMenuOpen, setMobileMenuOpen, user, onLogout }: any) => (
  <nav className="fixed top-0 w-full z-50 bg-brand-dark/90 backdrop-blur-md border-b border-white/10">
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-16">
        <div className="flex items-center">
          <Link to="/" className="text-2xl font-display font-bold text-white tracking-wider">
            AFTER HOUR <span className="text-brand-accent">BOTTLES</span>
          </Link>
        </div>
        <div className="hidden md:block">
          <div className="ml-10 flex items-baseline space-x-8">
            <Link to="/" className="text-gray-300 hover:text-white px-3 py-2 rounded-md font-medium">Home</Link>
            <Link to="/menu" className="text-gray-300 hover:text-white px-3 py-2 rounded-md font-medium">Menu</Link>
            <Link to="/delivery" className="text-gray-300 hover:text-white px-3 py-2 rounded-md font-medium">Delivery Map</Link>
            {user?.role === 'admin' && (
              <Link to="/admin" className="text-brand-accent hover:text-white px-3 py-2 rounded-md font-medium flex items-center gap-1">
                 <Lock size={14} /> Admin
              </Link>
            )}
          </div>
        </div>
        <div className="flex items-center gap-4">
            <a href={`tel:${PHONE_NUMBER}`} className="hidden md:flex items-center text-brand-success font-bold">
                <Phone className="w-4 h-4 mr-2" /> {PHONE_NUMBER}
            </a>
            
            {/* User Auth Section */}
            {user ? (
              <div className="hidden md:flex items-center gap-3 border-l border-white/10 pl-4">
                <div className="flex flex-col items-end">
                    <span className="text-sm text-gray-300 font-medium leading-none mb-1">
                    {user.role === 'admin' ? 'Admin' : `Hi, ${user.name}`}
                    </span>
                    <Link to="/orders" className="text-xs text-brand-accent hover:underline flex items-center">
                        <History size={10} className="mr-1" /> My Orders
                    </Link>
                </div>
                <button 
                  onClick={onLogout}
                  className="p-2 text-gray-400 hover:text-red-400 transition-colors"
                  title="Logout"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <Link 
                to="/login"
                className="hidden md:flex p-2 text-gray-300 hover:text-brand-accent transition-colors"
                title="Login"
              >
                <UserIcon className="w-5 h-5" />
              </Link>
            )}

          <button onClick={toggleCart} className="relative p-2 text-gray-300 hover:text-white">
            <ShoppingCart className="w-6 h-6" />
            {cartCount > 0 && (
              <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-brand-accent rounded-full">
                {cartCount}
              </span>
            )}
          </button>
          <div className="-mr-2 flex md:hidden">
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2 text-gray-400 hover:text-white">
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>
    </div>
    {/* Mobile Menu */}
    {mobileMenuOpen && (
      <div className="md:hidden bg-brand-dark border-b border-white/10">
        <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
          <Link to="/" onClick={() => setMobileMenuOpen(false)} className="block text-gray-300 hover:text-white px-3 py-2 rounded-md text-base font-medium">Home</Link>
          <Link to="/menu" onClick={() => setMobileMenuOpen(false)} className="block text-gray-300 hover:text-white px-3 py-2 rounded-md text-base font-medium">Menu</Link>
          <Link to="/delivery" onClick={() => setMobileMenuOpen(false)} className="block text-gray-300 hover:text-white px-3 py-2 rounded-md text-base font-medium">Delivery Map</Link>
          {user && <Link to="/orders" onClick={() => setMobileMenuOpen(false)} className="block text-gray-300 hover:text-white px-3 py-2 rounded-md text-base font-medium">My Orders</Link>}
          {user?.role === 'admin' && <Link to="/admin" onClick={() => setMobileMenuOpen(false)} className="block text-brand-accent hover:text-white px-3 py-2 rounded-md text-base font-medium">Admin Dashboard</Link>}
          
          <div className="border-t border-white/10 mt-4 pt-4">
             {user ? (
               <button onClick={() => { onLogout(); setMobileMenuOpen(false); }} className="flex w-full items-center text-red-400 px-3 py-2 rounded-md text-base font-medium">
                 <LogOut className="w-5 h-5 mr-2" /> Logout
               </button>
             ) : (
               <Link to="/login" onClick={() => setMobileMenuOpen(false)} className="flex items-center text-brand-accent px-3 py-2 rounded-md text-base font-medium">
                 <LogIn className="w-5 h-5 mr-2" /> Login
               </Link>
             )}
          </div>
        </div>
      </div>
    )}
  </nav>
);

const ProductCard: React.FC<any> = ({ product, addToCart, currentStock }) => {
  const [loadingInfo, setLoadingInfo] = useState(false);
  const [info, setInfo] = useState<string | null>(null);
  const [sources, setSources] = useState<GroundingChunk[]>([]);
  const [quantity, setQuantity] = useState(1);

  const isOutOfStock = currentStock === 0;
  const isLowStock = currentStock > 0 && currentStock <= 5;

  useEffect(() => {
    if (currentStock === 0) setQuantity(0);
    else if (quantity > currentStock) setQuantity(currentStock);
    else if (quantity === 0 && currentStock > 0) setQuantity(1);
  }, [currentStock]);

  const fetchInfo = async () => {
    if (info) { setInfo(null); return; }
    setLoadingInfo(true);
    const data = await getProductDetails(product.name);
    setInfo(data.details);
    setSources(data.sources);
    setLoadingInfo(false);
  };

  const handleAddToCart = () => {
    addToCart(product, quantity);
    if (currentStock - quantity > 0) setQuantity(1);
  };

  return (
    <div className={`bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:border-brand-accent hover:scale-[1.03] hover:shadow-[0_0_20px_rgba(168,85,247,0.3)] transition-all duration-300 flex flex-col group ${isOutOfStock ? 'opacity-70' : ''}`}>
      <div className="h-48 overflow-hidden relative bg-gray-900 flex items-center justify-center">
        <img 
          src={product.image} 
          alt={product.name}
          loading="lazy" 
          className={`w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-90 group-hover:opacity-100 ${isOutOfStock ? 'grayscale' : ''}`} 
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent"></div>
        <div className="absolute top-2 left-2 px-2 py-1 bg-black/60 backdrop-blur text-xs font-bold text-gray-300 rounded uppercase border border-white/10 z-10">{product.category}</div>
        
        {product.promo && !isOutOfStock && (
            <div className="absolute top-2 right-2 z-20">
               <div className="relative group/promo">
                  <div className="absolute inset-0 bg-brand-accent/80 blur-md animate-pulse"></div>
                  <div className="relative px-4 py-1.5 bg-brand-dark/90 border border-brand-accent text-white text-xs font-black rounded-full shadow-[0_0_15px_rgba(168,85,247,0.8)] flex items-center gap-1 uppercase tracking-wider transform group-hover/promo:scale-105 transition-transform">
                    <Tag size={12} fill="currentColor" className="text-brand-accent" /> {product.promo.label}
                  </div>
               </div>
            </div>
        )}

        {isOutOfStock && (
            <div className="absolute inset-0 z-20 flex items-center justify-center overflow-hidden">
                <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px]"></div>
                <div className="absolute inset-0 opacity-30 pointer-events-none" style={{ 
                    backgroundImage: 'linear-gradient(45deg, transparent 45%, rgba(255,255,255,0.8) 49%, rgba(255,255,255,0.8) 51%, transparent 55%), linear-gradient(-45deg, transparent 45%, rgba(255,255,255,0.8) 49%, rgba(255,255,255,0.8) 51%, transparent 55%)', 
                    backgroundSize: '100% 100%' 
                }}></div>
                <div className="relative border-4 border-red-600/80 p-4 -rotate-12 bg-black/90 shadow-[0_0_30px_rgba(220,38,38,0.6)]">
                    <span className="text-red-500 font-display font-bold text-2xl uppercase tracking-widest whitespace-nowrap">SOLD OUT</span>
                </div>
            </div>
        )}
        
        {!product.promo && !isOutOfStock && (
             <button onClick={fetchInfo} className="absolute top-2 right-2 p-2 bg-black/60 backdrop-blur rounded-full text-brand-accent hover:bg-brand-accent hover:text-white transition-colors z-10 border border-white/10" title="Ask AI about this"><Info size={16} /></button>
        )}
      </div>
      
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-white leading-tight">{product.name}</h3>
          <div className="flex flex-col items-end">
             <span className="text-brand-success font-display font-bold text-xl whitespace-nowrap ml-2">${product.price}</span>
          </div>
        </div>
        
        {loadingInfo && <p className="text-xs text-brand-accent animate-pulse mb-2">Consulting Sommelier AI...</p>}
        {info && (
            <div className="mb-3 p-2 bg-brand-accent/10 rounded border border-brand-accent/20 text-xs text-gray-300">
                <p>{info}</p>
                {sources.length > 0 && (
                    <div className="mt-1 pt-1 border-t border-white/10 flex flex-wrap gap-2">
                        {sources.map((s, i) => s.web?.uri && (
                            <a key={i} href={s.web.uri} target="_blank" rel="noreferrer" className="flex items-center text-[10px] text-brand-accent hover:underline">Source <ExternalLink size={8} className="ml-1" /></a>
                        ))}
                    </div>
                )}
            </div>
        )}

        <div className="mt-auto pt-3 space-y-3">
          {isLowStock && !isOutOfStock && (
            <div className="flex items-center gap-1.5 text-orange-400 text-xs font-bold bg-orange-500/10 p-2 rounded border border-orange-500/20">
                <AlertTriangle size={12} />
                <span>Hurry! Only {currentStock} left</span>
            </div>
          )}

          {!isOutOfStock && (
            <div className="flex items-center justify-between bg-zinc-900 border border-white/10 rounded-lg p-1">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))} disabled={quantity <= 1} className="p-2 hover:bg-white/10 rounded-md text-gray-400 hover:text-white disabled:opacity-30"><Minus size={16} /></button>
                <span className="font-bold font-mono text-white w-8 text-center">{quantity}</span>
                <button onClick={() => setQuantity(Math.min(currentStock, quantity + 1))} disabled={quantity >= currentStock} className="p-2 hover:bg-white/10 rounded-md text-gray-400 hover:text-white disabled:opacity-30"><Plus size={16} /></button>
            </div>
          )}

          <button 
            onClick={handleAddToCart}
            disabled={isOutOfStock}
            className={`w-full font-bold py-3 px-4 rounded-lg transition-all flex items-center justify-center gap-2 ${
                isOutOfStock 
                ? 'bg-zinc-800 text-gray-500 cursor-not-allowed border border-white/5' 
                : 'bg-white/10 hover:bg-brand-accent text-white hover:shadow-[0_0_15px_rgba(168,85,247,0.4)]'
            }`}
          >
            {isOutOfStock ? 'Out of Stock' : <><ShoppingCart size={18} /> Add to Cart</>}
          </button>
        </div>
      </div>
    </div>
  );
};

const CartDrawer = ({ isOpen, onClose, cart, updateQuantity, removeFromCart, onCheckoutStart }: any) => {
  const [deliveryMethod, setDeliveryMethod] = useState<'Delivery' | 'Pickup'>('Delivery');
  const [instructions, setInstructions] = useState('');
  
  if (!isOpen) return null;
  const total = cart.reduce((acc: number, item: CartItem) => acc + calculateItemTotal(item), 0);
  const finalTotal = total + (deliveryMethod === 'Delivery' ? DELIVERY_FEE : 0);

  return (
    <div className="fixed inset-0 z-[60] flex justify-end">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative w-full max-w-md bg-zinc-900 border-l border-white/10 shadow-2xl flex flex-col h-full animate-slide-in-right">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
            <h2 className="text-xl font-display font-bold text-white flex items-center gap-2"><ShoppingCart className="text-brand-accent" /> Your Cart</h2>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full"><X size={20} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {cart.length === 0 ? (
                <div className="text-center text-gray-500 mt-20"><Package size={48} className="mx-auto mb-4 opacity-20" /><p>Your cart is empty.</p><button onClick={onClose} className="mt-4 text-brand-accent hover:underline">Start Shopping</button></div>
            ) : (
                cart.map((item: CartItem) => (
                    <div key={item.id} className="bg-white/5 rounded-lg p-3 flex gap-3">
                        <img src={item.image} className="w-16 h-16 rounded object-cover" alt="" />
                        <div className="flex-1">
                            <div className="flex justify-between"><h3 className="font-bold text-sm">{item.name}</h3><span className="font-mono text-brand-accent font-bold">${calculateItemTotal(item).toFixed(2)}</span></div>
                            <p className="text-xs text-gray-400 mb-2">{item.quantity} x ${item.price}</p>
                            <div className="flex items-center gap-3">
                                <div className="flex items-center bg-black/30 rounded"><button onClick={() => updateQuantity(item.id, -1)} className="p-1 hover:bg-white/10"><Minus size={12} /></button><span className="px-2 text-xs font-mono">{item.quantity}</span><button onClick={() => updateQuantity(item.id, 1)} className="p-1 hover:bg-white/10"><Plus size={12} /></button></div>
                                <button onClick={() => removeFromCart(item.id)} className="text-xs text-red-400 hover:text-red-300">Remove</button>
                            </div>
                        </div>
                    </div>
                ))
            )}
        </div>
        {cart.length > 0 && (
            <div className="p-4 bg-black/20 border-t border-white/10 space-y-4">
                <div className="flex bg-black/40 p-1 rounded-lg">
                    <button onClick={() => setDeliveryMethod('Delivery')} className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${deliveryMethod === 'Delivery' ? 'bg-brand-accent text-white shadow' : 'text-gray-400 hover:text-white'}`}>Delivery</button>
                    <button onClick={() => setDeliveryMethod('Pickup')} className={`flex-1 py-2 text-sm font-bold rounded-md transition-all ${deliveryMethod === 'Pickup' ? 'bg-brand-accent text-white shadow' : 'text-gray-400 hover:text-white'}`}>Pickup</button>
                </div>
                {deliveryMethod === 'Delivery' && (<div className="text-xs text-gray-400 bg-blue-500/10 border border-blue-500/20 p-2 rounded flex items-start gap-2"><Info size={14} className="mt-0.5 shrink-0 text-blue-400" /><span>Delivery generally takes 15-45 minutes depending on traffic.</span></div>)}
                <textarea placeholder="Special instructions (e.g. gate code, leave at door)..." className="w-full bg-black/30 border border-white/10 rounded-lg p-2 text-sm text-white resize-none h-20 focus:border-brand-accent outline-none" value={instructions} onChange={(e) => setInstructions(e.target.value)} />
                <div className="space-y-2 text-sm">
                    <div className="flex justify-between text-gray-400"><span>Subtotal</span><span>${total.toFixed(2)}</span></div>
                    {deliveryMethod === 'Delivery' && (<div className="flex justify-between text-gray-400"><span>Delivery Fee</span><span>${DELIVERY_FEE.toFixed(2)}</span></div>)}
                    <div className="flex justify-between text-xl font-bold text-white pt-2 border-t border-white/10"><span>Total</span><span>${finalTotal.toFixed(2)}</span></div>
                </div>
                <button onClick={() => onCheckoutStart({ deliveryMethod, instructions, total: finalTotal })} className="w-full bg-brand-success hover:bg-green-400 text-black font-bold py-3 rounded-lg text-lg shadow-lg hover:shadow-green-500/20 transition-all flex items-center justify-center gap-2">Checkout <ChevronRight size={20} /></button>
            </div>
        )}
      </div>
    </div>
  );
};

const PaymentModal = ({ isOpen, onClose, total, onConfirm }: any) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
             <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
             <div className="relative bg-zinc-900 border border-white/10 rounded-2xl w-full max-w-md p-6 shadow-2xl animate-scale-in">
                 <h2 className="text-2xl font-bold text-white mb-6 text-center">Select Payment Method</h2>
                 <p className="text-gray-400 text-center mb-8">Total Amount: <span className="text-white font-mono text-xl font-bold">${total.toFixed(2)}</span></p>
                 <div className="space-y-3">
                     <button onClick={() => onConfirm('cashapp')} className="w-full bg-[#00D632] hover:bg-[#00D632]/90 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-transform hover:scale-[1.02]"><DollarSign size={20} /> Cash App</button>
                     <button onClick={() => onConfirm('cash')} className="w-full bg-zinc-700 hover:bg-zinc-600 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-transform hover:scale-[1.02]"><Banknote size={20} /> Cash on Delivery</button>
                 </div>
                 <button onClick={onClose} className="mt-6 w-full py-2 text-gray-500 hover:text-gray-300">Cancel</button>
             </div>
        </div>
    );
};

const Footer = () => (
    <footer className="bg-zinc-900 border-t border-white/10 py-8 mt-auto relative z-10">
      <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="text-center md:text-left">
          <h3 className="font-display font-bold text-white tracking-wider">AFTER HOUR <span className="text-brand-accent">BOTTLES</span></h3>
          <p className="text-xs text-gray-500 mt-1">© 2024. All rights reserved.</p>
        </div>
        <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-gray-500 text-xs border-r border-white/10 pr-6 mr-6 hidden md:flex">
                <Cloud size={14} /> <span>Powered by Google Cloud</span>
            </div>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition-colors flex items-center gap-2">
                <Github size={20} /> <span className="text-xs font-bold">View Source</span>
            </a>
        </div>
      </div>
    </footer>
);

const Home = () => (
    <div className="relative min-h-screen">
        <div className="h-screen relative flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1569937756447-e1975e54c7d5?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center"></div>
            <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-brand-dark"></div>
            <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
                <h1 className="text-5xl md:text-7xl font-display font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-200 to-gray-500 mb-6 drop-shadow-2xl tracking-tight">AFTER HOUR <span className="text-brand-accent">BOTTLES</span></h1>
                <p className="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto font-light">Premium liquor delivered to your door. <br/> <span className="text-brand-success font-bold">Open Late. Fast Delivery.</span></p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Link to="/menu" className="px-8 py-4 bg-brand-accent hover:bg-purple-600 text-white font-bold rounded-full text-lg shadow-[0_0_20px_rgba(168,85,247,0.4)] hover:shadow-[0_0_30px_rgba(168,85,247,0.6)] transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"><Store size={20} /> Order Now</Link>
                    <Link to="/delivery" className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-full text-lg backdrop-blur-sm border border-white/10 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"><MapPin size={20} /> Check Delivery Range</Link>
                </div>
            </div>
        </div>
    </div>
);

const MenuPage = ({ addToCart, inventory, products }: any) => {
    const [selectedCategory, setSelectedCategory] = useState<string>('All');
    const categories = ['All', ...Object.values(Category)];
    const filteredProducts = selectedCategory === 'All' ? products : products.filter((p: Product) => p.category === selectedCategory);

    return (
        <div className="pt-24 pb-12 px-4 max-w-7xl mx-auto min-h-screen">
             <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
                 <h2 className="text-3xl font-display font-bold text-white">Our Selection</h2>
                 <div className="flex overflow-x-auto pb-2 md:pb-0 gap-2 hide-scrollbar">
                     {categories.map(cat => (<button key={cat} onClick={() => setSelectedCategory(cat)} className={`px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all ${selectedCategory === cat ? 'bg-brand-accent text-white shadow-lg' : 'bg-white/5 text-gray-400 hover:text-white'}`}>{cat}</button>))}
                 </div>
             </div>
             <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                 {filteredProducts.map((product: Product) => (<ProductCard key={product.id} product={product} addToCart={addToCart} currentStock={inventory[product.id] ?? 0} />))}
             </div>
        </div>
    );
};

const DeliveryCheckPage = () => {
    const [address, setAddress] = useState('');
    const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
    const [result, setResult] = useState<{ allowed: boolean; message: string; sources: GroundingChunk[] } | null>(null);
    const [mapUserLocation, setMapUserLocation] = useState<[number, number] | null>(null);

    const handleCheck = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!address) return;
        setStatus('loading');
        setResult(null);
        setMapUserLocation(null);

        const res = await checkDeliveryLocation(address);
        setResult(res);
        setStatus('success');
        
        // Simulating coordinate lookup for demo (Random point near MKE)
        if (res.allowed) {
            // Milwaukee Center is [43.0389, -87.9065]
            // Add random offset
            const lat = 43.0389 + (Math.random() - 0.5) * 0.1;
            const lng = -87.9065 + (Math.random() - 0.5) * 0.1;
            setMapUserLocation([lat, lng]);
        }
    };

    return (
        <div className="pt-24 pb-12 px-4 max-w-5xl mx-auto min-h-screen flex flex-col items-center">
            <h2 className="text-3xl font-display font-bold text-white mb-2 text-center">Delivery Zone Check</h2>
            <p className="text-gray-400 mb-8 text-center max-w-lg">Enter your address to see if you are within our 20-mile delivery radius of Milwaukee.</p>
            
            <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                <div className="order-2 md:order-1">
                     <form onSubmit={handleCheck} className="w-full relative mb-8">
                        <input type="text" placeholder="Enter your full address..." className="w-full bg-zinc-900 border border-white/20 rounded-full px-6 py-4 pr-14 text-white focus:border-brand-accent focus:shadow-[0_0_20px_rgba(168,85,247,0.2)] outline-none transition-all" value={address} onChange={(e) => setAddress(e.target.value)} />
                        <button type="submit" disabled={status === 'loading'} className="absolute right-2 top-2 bottom-2 bg-brand-accent hover:bg-purple-600 text-white w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-50 transition-colors">
                            {status === 'loading' ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div> : <Search size={20} />}
                        </button>
                    </form>
                    {result && (
                        <div className={`w-full p-6 rounded-xl border ${result.allowed ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'} animate-fade-in`}>
                            <div className="flex items-start gap-4">
                                <div className={`p-3 rounded-full ${result.allowed ? 'bg-green-500 text-black' : 'bg-red-500 text-white'}`}>{result.allowed ? <CheckCircle size={24} /> : <AlertTriangle size={24} />}</div>
                                <div>
                                    <h3 className={`text-xl font-bold mb-1 ${result.allowed ? 'text-green-400' : 'text-red-400'}`}>{result.allowed ? 'You are in range!' : 'Out of Delivery Range'}</h3>
                                    <p className="text-gray-300 text-sm leading-relaxed mb-3">{result.message}</p>
                                    {result.sources.length > 0 && (<div className="mt-2 text-xs text-gray-500"><p className="uppercase font-bold tracking-wider mb-1 opacity-70">Verified via Google Maps</p><div className="flex flex-wrap gap-2">{result.sources.map((s, i) => s.maps?.uri && (<a key={i} href={s.maps.uri} target="_blank" rel="noreferrer" className="flex items-center hover:text-brand-accent hover:underline">View on Map <ExternalLink size={10} className="ml-1" /></a>))}</div></div>)}
                                </div>
                            </div>
                            {result.allowed && (<Link to="/menu" className="block w-full text-center bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-lg mt-6 shadow-lg transition-colors">Start Your Order</Link>)}
                        </div>
                    )}
                </div>

                <div className="order-1 md:order-2 h-[400px] w-full rounded-2xl overflow-hidden shadow-2xl border border-white/10 relative">
                     <MapComponent userLocation={mapUserLocation} />
                     <div className="absolute top-4 left-4 bg-black/80 backdrop-blur px-3 py-1 rounded text-xs text-brand-accent font-bold border border-brand-accent/30 z-[400]">
                         Visual Aid: 20-mile Radius
                     </div>
                </div>
            </div>
        </div>
    );
};

// NEW: Order Tracking Page with Live Map Simulation
const OrderTrackingPage = ({ orders, user }: { orders: Order[], user: User }) => {
    const { orderId } = useParams();
    const order = orders.find(o => o.id === orderId);
    
    // Simulating driver position
    const [driverPos, setDriverPos] = useState<[number, number] | null>(null);
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        if (order?.status === 'Delivering' || order?.status === 'Accepted') {
            // Milwaukee Center
            const start: [number, number] = [43.0389, -87.9065];
            // Simulate Customer Location (Fixed offset for demo)
            const end: [number, number] = [43.05, -87.95]; 

            // Initialize
            setDriverPos(start);

            // Simulation Loop
            const interval = setInterval(() => {
                setProgress(p => {
                    if (p >= 1) return 0; // Reset for demo loop
                    return p + 0.005; // Move speed
                });
            }, 100);

            return () => clearInterval(interval);
        }
    }, [order?.status]);

    useEffect(() => {
        if (driverPos && progress > 0) {
            const start = [43.0389, -87.9065];
            const end = [43.05, -87.95];
            const lat = start[0] + (end[0] - start[0]) * progress;
            const lng = start[1] + (end[1] - start[1]) * progress;
            setDriverPos([lat, lng]);
        }
    }, [progress]);

    if (!order) return <div className="pt-32 text-center text-red-500">Order not found</div>;

    return (
        <div className="pt-24 pb-12 px-4 max-w-6xl mx-auto min-h-screen">
            <Link to="/orders" className="inline-flex items-center text-gray-400 hover:text-white mb-6"><ArrowLeft size={16} className="mr-2" /> Back to Orders</Link>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                    <div className="bg-zinc-900 border border-white/10 rounded-2xl overflow-hidden shadow-2xl relative">
                        <MapComponent driverLocation={driverPos} userLocation={[43.05, -87.95]} height="500px" />
                        <div className="absolute top-4 right-4 z-[400] bg-black/80 backdrop-blur px-4 py-2 rounded-lg border border-white/10">
                            <p className="text-xs text-gray-400 uppercase tracking-wider font-bold">Estimated Arrival</p>
                            <p className="text-xl font-bold text-brand-success font-display">{order.estimatedDeliveryTime || 'Calculating...'}</p>
                        </div>
                    </div>
                </div>

                <div className="bg-zinc-900 border border-white/10 rounded-2xl p-6 h-fit">
                    <h2 className="text-2xl font-display font-bold text-white mb-1">Order #{order.id.slice(0,8)}</h2>
                    <p className={`text-sm font-bold uppercase tracking-wider mb-6 ${
                         order.status === 'Completed' ? 'text-green-400' : 
                         order.status === 'Delivering' ? 'text-orange-400' :
                         order.status === 'Accepted' ? 'text-blue-400' : 'text-brand-accent'
                    }`}>{order.status}</p>

                    <div className="space-y-6 relative">
                         {/* Timeline */}
                         <div className="absolute left-2 top-2 bottom-2 w-0.5 bg-white/10"></div>
                         
                         {[
                             { s: 'Pending', label: 'Order Received', icon: FileText },
                             { s: 'Accepted', label: 'Order Accepted', icon: CheckCircle },
                             { s: 'Delivering', label: 'Out for Delivery', icon: Truck },
                             { s: 'Completed', label: 'Delivered', icon: CheckSquare }
                         ].map((step, i) => {
                             const isCompleted = ['Pending', 'Accepted', 'Delivering', 'Completed'].indexOf(order.status) >= i;
                             const isCurrent = order.status === step.s;
                             
                             return (
                                 <div key={step.s} className={`relative pl-8 flex items-center ${isCompleted ? 'opacity-100' : 'opacity-30'}`}>
                                     <div className={`absolute left-0 w-4 h-4 rounded-full border-2 ${isCurrent ? 'bg-brand-accent border-brand-accent animate-pulse' : isCompleted ? 'bg-green-500 border-green-500' : 'bg-black border-gray-600'}`}></div>
                                     <div>
                                         <p className={`font-bold ${isCurrent ? 'text-brand-accent' : 'text-white'}`}>{step.label}</p>
                                         {isCurrent && <p className="text-xs text-gray-400 mt-1">Happening now</p>}
                                     </div>
                                 </div>
                             )
                         })}
                    </div>
                    
                    <div className="mt-8 pt-6 border-t border-white/10">
                        <h3 className="font-bold text-white mb-2">Delivery Details</h3>
                        <p className="text-sm text-gray-400">{order.customerAddress || '123 Fake St, Milwaukee, WI'}</p>
                        {order.deliveryInstructions && <p className="text-sm text-gray-500 mt-2 italic">"{order.deliveryInstructions}"</p>}
                    </div>

                    <div className="mt-6">
                         <a href={`tel:${PHONE_NUMBER}`} className="flex items-center justify-center w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-white font-bold transition-colors">
                             <Phone size={18} className="mr-2"/> Contact Support
                         </a>
                    </div>
                </div>
            </div>
        </div>
    );
};

const LoginPage = ({ onLogin, onSignup }: any) => {
    const [isSignup, setIsSignup] = useState(false);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isSignup) {
            onSignup(name, email, password);
        } else {
            onLogin(email, password);
        }
        navigate('/');
    };

    const handleReset = () => {
        if(email) {
            sendPasswordResetEmail(email);
        } else {
            alert("Enter email first");
        }
    };

    return (
        <div className="min-h-screen pt-20 flex items-center justify-center px-4">
             <div className="bg-zinc-900 border border-white/10 p-8 rounded-2xl w-full max-w-md shadow-2xl">
                 <h2 className="text-3xl font-display font-bold text-center mb-6 text-white">
                     {isSignup ? 'Join the Party' : 'Welcome Back'}
                 </h2>
                 <form onSubmit={handleSubmit} className="space-y-4">
                     {isSignup && (
                         <div>
                             <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Name</label>
                             <input type="text" className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:border-brand-accent outline-none" value={name} onChange={e => setName(e.target.value)} required />
                         </div>
                     )}
                     <div>
                         <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Email</label>
                         <input type="email" className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:border-brand-accent outline-none" value={email} onChange={e => setEmail(e.target.value)} required />
                     </div>
                     <div>
                         <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Password</label>
                         <input type="password" className="w-full bg-black/50 border border-white/10 rounded-lg p-3 text-white focus:border-brand-accent outline-none" value={password} onChange={e => setPassword(e.target.value)} required />
                     </div>
                     
                     <button type="submit" className="w-full bg-brand-accent hover:bg-purple-600 text-white font-bold py-3 rounded-lg shadow-lg transition-all mt-2">
                         {isSignup ? 'Create Account' : 'Login'}
                     </button>
                 </form>

                 <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-white/10"></div>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-zinc-900 px-2 text-gray-500">Or continue with</span>
                    </div>
                 </div>

                 <button 
                    onClick={() => alert("Google Login Simulated: Redirecting to OAuth...")}
                    className="w-full bg-white hover:bg-gray-100 text-gray-900 font-bold py-3 rounded-lg shadow-lg transition-all flex items-center justify-center gap-2"
                 >
                    <svg className="w-5 h-5" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg>
                    Continue with Google
                 </button>

                 {!isSignup && (
                     <button onClick={handleReset} className="block w-full text-center text-xs text-gray-500 hover:text-white mt-4">Forgot Password?</button>
                 )}

                 <div className="mt-6 pt-6 border-t border-white/10 text-center">
                     <p className="text-gray-400 text-sm">
                         {isSignup ? 'Already have an account?' : "Don't have an account?"}
                         <button onClick={() => setIsSignup(!isSignup)} className="ml-2 text-brand-accent font-bold hover:underline">
                             {isSignup ? 'Login' : 'Sign Up'}
                         </button>
                     </p>
                 </div>
             </div>
        </div>
    );
};

const OrdersPage = ({ orders, user, onReorder }: { orders: Order[], user: User, onReorder: (order: Order) => void }) => {
    const myOrders = orders.filter(o => o.userId === user.id);
    const sortedOrders = [...myOrders].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return (
        <div className="pt-24 pb-12 px-4 max-w-4xl mx-auto min-h-screen">
            <h2 className="text-3xl font-display font-bold text-white mb-8">My Order History</h2>
            {sortedOrders.length === 0 ? (
                <div className="text-center text-gray-500"><History className="w-16 h-16 mx-auto mb-4 opacity-20" /><p>No orders yet. Time to stock up!</p></div>
            ) : (
                <div className="space-y-4">
                    {sortedOrders.map(order => (
                        <div key={order.id} className="bg-zinc-900 border border-white/10 rounded-xl p-4 sm:p-6 transition-all hover:border-brand-accent/30">
                            <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 pb-4 border-b border-white/10">
                                <div>
                                    <span className="text-xs text-gray-500 uppercase tracking-wider">Order ID</span>
                                    <p className="font-mono text-white">#{order.id.slice(0,8)}</p>
                                </div>
                                <div className="mt-2 sm:mt-0 flex flex-col items-end">
                                    <div className="flex items-center gap-4">
                                        <span className="text-sm text-gray-400">{new Date(order.date).toLocaleDateString()}</span>
                                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                            order.status === 'Completed' ? 'bg-green-500/20 text-green-400' : 
                                            order.status === 'Delivering' ? 'bg-orange-500/20 text-orange-400 animate-pulse' :
                                            order.status === 'Accepted' ? 'bg-blue-500/20 text-blue-400' :
                                            'bg-brand-accent/20 text-brand-accent'
                                        }`}>{order.status}</span>
                                    </div>
                                    {order.status !== 'Completed' && (
                                        <div className="mt-2 text-right">
                                            {order.estimatedDeliveryTime && (
                                                <span className="text-xs text-brand-accent flex items-center justify-end gap-1 font-bold">
                                                    <Clock size={12} /> ETA: {order.estimatedDeliveryTime}
                                                </span>
                                            )}
                                            <Link to={`/track/${order.id}`} className="inline-block mt-2 text-xs bg-white/10 hover:bg-brand-accent px-3 py-1 rounded text-white transition-colors">
                                                Track Live Order &rarr;
                                            </Link>
                                        </div>
                                    )}
                                </div>
                            </div>
                            <div className="space-y-2 mb-4">
                                {order.items.map(item => (
                                    <div key={item.id} className="flex justify-between text-sm">
                                        <span className="text-gray-300">{item.quantity}x {item.name}</span>
                                        <span className="text-gray-400">${(item.price * item.quantity).toFixed(2)}</span>
                                    </div>
                                ))}
                            </div>
                            <div className="flex justify-between items-center pt-2 border-t border-white/10">
                                <div>
                                    <span className="font-bold text-white block">Total</span>
                                    <span className="font-bold text-brand-success">${order.total.toFixed(2)}</span>
                                </div>
                                <button onClick={() => onReorder(order)} className="flex items-center gap-2 bg-brand-accent/20 text-brand-accent hover:bg-brand-accent hover:text-white px-4 py-2 rounded-lg text-sm font-bold transition-colors">
                                    <RotateCcw size={16} /> Reorder
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

const AdminDashboard = ({ inventory, orders, updateStock, updateOrderStatus, products, updatePrice, addProduct, updatePromo }: any) => {
    const [activeTab, setActiveTab] = useState<'ops' | 'reports'>('ops');
    const [dateRange, setDateRange] = useState<'daily' | 'weekly' | 'monthly'>('daily');
    const [sortSalesBy, setSortSalesBy] = useState<'revenue' | 'quantity'>('revenue');
    const [showAddProduct, setShowAddProduct] = useState(false);
    const [newProduct, setNewProduct] = useState({ name: '', price: '', category: 'Pint', stock: '' });
    const [editingPromo, setEditingPromo] = useState<string | null>(null);
    const [promoData, setPromoData] = useState({ buyQuantity: 2, price: 0, label: '' });

    const salesReport = useMemo(() => {
        const now = new Date();
        const filteredOrders = orders.filter((o: Order) => {
            if (o.status !== 'Completed') return false;
            const orderDate = new Date(o.date);
            if (dateRange === 'daily') return orderDate.getDate() === now.getDate() && orderDate.getMonth() === now.getMonth() && orderDate.getFullYear() === now.getFullYear();
            if (dateRange === 'weekly') { const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000); return orderDate >= oneWeekAgo; }
            if (dateRange === 'monthly') return orderDate.getMonth() === now.getMonth() && orderDate.getFullYear() === now.getFullYear();
            return true;
        });
        
        const productStats: Record<string, { name: string, quantity: number, revenue: number }> = {};
        const paymentStats: Record<string, number> = {};

        filteredOrders.forEach((order: Order) => {
            const method = order.paymentMethod || 'Unknown';
            paymentStats[method] = (paymentStats[method] || 0) + order.total;
            order.items.forEach((item: CartItem) => {
                if (!productStats[item.id]) productStats[item.id] = { name: item.name, quantity: 0, revenue: 0 };
                productStats[item.id].quantity += item.quantity;
                productStats[item.id].revenue += calculateItemTotal(item);
            });
        });

        const sortedProducts = Object.values(productStats).sort((a,b) => sortSalesBy === 'quantity' ? b.quantity - a.quantity : b.revenue - a.revenue);
        return { productStats: sortedProducts, paymentStats, totalRevenue: Object.values(paymentStats).reduce((a, b) => a + b, 0) };
    }, [orders, dateRange, sortSalesBy]);

    const handleAddProductSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (newProduct.name && newProduct.price) {
            addProduct({ name: newProduct.name, price: parseFloat(newProduct.price), category: newProduct.category, stock: parseInt(newProduct.stock) || 0, image: 'https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=600&auto=format&fit=crop' });
            setShowAddProduct(false);
            setNewProduct({ name: '', price: '', category: 'Pint', stock: '' });
        }
    };

    const savePromo = (productId: string) => { updatePromo(productId, promoData.buyQuantity > 0 ? promoData : undefined); setEditingPromo(null); };

    return (
        <div className="pt-24 pb-12 px-4 max-w-7xl mx-auto min-h-screen">
            <h1 className="text-3xl font-bold text-white mb-8 flex items-center gap-3"><LayoutDashboard /> Admin Dashboard</h1>

            {/* Infrastructure Status Panel */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8 animate-fade-in">
                <div className="bg-zinc-900 border border-white/10 p-4 rounded-xl flex items-center gap-4 shadow-lg">
                    <div className="p-3 bg-blue-500/10 rounded-full text-blue-400 border border-blue-500/20"><Cloud size={24}/></div>
                    <div><p className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Cloud Hosting</p><p className="font-bold text-white text-sm flex items-center gap-2">Google Cloud <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.8)] animate-pulse"></span></p></div>
                </div>
                <div className="bg-zinc-900 border border-white/10 p-4 rounded-xl flex items-center gap-4 shadow-lg">
                    <div className="p-3 bg-white/5 rounded-full text-white border border-white/10"><Github size={24}/></div>
                    <div><p className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Source Control</p><p className="font-bold text-white text-sm flex items-center gap-2">GitHub Repo <span className="text-[10px] bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded border border-green-500/30">Synced</span></p></div>
                </div>
                <div className="bg-zinc-900 border border-white/10 p-4 rounded-xl flex items-center gap-4 shadow-lg">
                    <div className="p-3 bg-brand-accent/10 rounded-full text-brand-accent border border-brand-accent/20"><Database size={24}/></div>
                    <div><p className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Database</p><p className="font-bold text-white text-sm flex items-center gap-2">Firestore <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.8)]"></span></p></div>
                </div>
            </div>

            <div className="flex gap-4 mb-8">
                <button onClick={() => setActiveTab('ops')} className={`px-6 py-2 rounded-lg font-bold transition-all ${activeTab === 'ops' ? 'bg-brand-accent text-white' : 'bg-white/5 text-gray-400 hover:text-white'}`}>Operations Center</button>
                <button onClick={() => setActiveTab('reports')} className={`px-6 py-2 rounded-lg font-bold transition-all ${activeTab === 'reports' ? 'bg-brand-accent text-white' : 'bg-white/5 text-gray-400 hover:text-white'}`}>Sales Reports</button>
            </div>

            {activeTab === 'ops' ? (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div className="bg-zinc-900 border border-white/10 rounded-xl p-6 lg:col-span-1">
                        <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2"><Truck /> Live Orders & Tracking</h2>
                        <div className="mb-6 rounded-lg h-48 relative overflow-hidden flex items-center justify-center">
                            {/* Live Map for Admin */}
                             <MapComponent driverLocation={[43.045, -87.91]} showZone={false} height="100%" />
                             <div className="absolute bottom-2 left-2 bg-black/80 backdrop-blur px-2 py-1 rounded text-xs border border-white/10 z-[400]">Simulating Driver #1</div>
                        </div>
                        <div className="space-y-4 max-h-[500px] overflow-y-auto">
                            {orders.filter((o: Order) => o.status !== 'Completed').length === 0 ? ( <p className="text-gray-500 italic">No active orders.</p> ) : (
                                orders.filter((o: Order) => o.status !== 'Completed').map((o: Order) => (
                                    <div key={o.id} className="bg-black/30 p-4 rounded-lg border border-white/5 relative overflow-hidden group">
                                        <div className={`absolute left-0 top-0 bottom-0 w-1 ${o.status === 'Pending' ? 'bg-brand-accent' : o.status === 'Accepted' ? 'bg-blue-500' : 'bg-orange-500'}`}></div>
                                        <div className="pl-3">
                                            <div className="flex justify-between mb-2">
                                                <div><span className="text-brand-accent font-mono text-sm block">#{o.id.slice(0,8)}</span><span className="text-xs text-gray-400">{new Date(o.date).toLocaleTimeString()}</span></div>
                                                <div className="text-right"><span className="text-white font-bold block">${o.total.toFixed(2)}</span><span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${o.status === 'Pending' ? 'bg-brand-accent/20 text-brand-accent' : o.status === 'Accepted' ? 'bg-blue-500/20 text-blue-400' : 'bg-orange-500/20 text-orange-400'}`}>{o.status}</span></div>
                                            </div>
                                            <div className="text-sm text-gray-300 mb-3 bg-white/5 p-2 rounded">{o.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}</div>
                                            {o.estimatedDeliveryTime && (<div className="text-xs text-brand-success mb-3 flex items-center gap-1"><Navigation size={12} /> Target: {o.estimatedDeliveryTime}</div>)}
                                            <div className="flex gap-2 mt-2">
                                                {o.status === 'Pending' && (<button onClick={() => updateOrderStatus(o.id, 'Accepted')} className="flex-1 bg-brand-accent hover:bg-purple-600 text-white text-xs font-bold py-2 rounded transition-colors">Accept Order</button>)}
                                                {o.status === 'Accepted' && (<button onClick={() => updateOrderStatus(o.id, 'Delivering')} className="flex-1 bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold py-2 rounded transition-colors">Send Driver</button>)}
                                                {o.status === 'Delivering' && (<button onClick={() => updateOrderStatus(o.id, 'Completed')} className="flex-1 bg-green-600 hover:bg-green-500 text-white text-xs font-bold py-2 rounded transition-colors flex items-center justify-center gap-1"><CheckSquare size={12} /> Delivered</button>)}
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                    <div className="bg-zinc-900 border border-white/10 rounded-xl p-6 lg:col-span-1">
                        <div className="flex justify-between items-center mb-4"><h2 className="text-xl font-bold text-white flex items-center gap-2"><ClipboardList /> Inventory</h2><button onClick={() => setShowAddProduct(!showAddProduct)} className="text-xs bg-brand-accent px-3 py-1 rounded font-bold flex items-center gap-1 hover:bg-white hover:text-black transition-colors"><PlusCircle size={14}/> Add New</button></div>
                        {showAddProduct && (
                            <form onSubmit={handleAddProductSubmit} className="mb-6 bg-white/5 p-4 rounded-lg border border-brand-accent/30 animate-fade-in">
                                <h3 className="font-bold text-sm mb-3 text-brand-accent">New Product Details</h3>
                                <div className="grid grid-cols-2 gap-3 mb-3">
                                    <input placeholder="Name" className="bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} required />
                                    <input type="number" placeholder="Price" className="bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} required />
                                    <select className="bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white" value={newProduct.category} onChange={e => setNewProduct({...newProduct, category: e.target.value})}>{Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}</select>
                                    <input type="number" placeholder="Stock" className="bg-black/50 border border-white/10 rounded px-3 py-2 text-sm text-white" value={newProduct.stock} onChange={e => setNewProduct({...newProduct, stock: e.target.value})} />
                                </div>
                                <button type="submit" className="w-full bg-brand-success text-black font-bold py-2 rounded text-sm hover:bg-green-400">Save Product</button>
                            </form>
                        )}
                        <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                            {products.map((p: Product) => (
                                <div key={p.id} className="bg-black/30 p-3 rounded-lg border border-white/5">
                                    <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-3"><img src={p.image} className="w-10 h-10 rounded object-cover" alt="" /><div><p className="text-white font-medium text-sm">{p.name}</p><p className="text-xs text-gray-500">{p.category}</p></div></div>
                                        <div className="flex flex-col items-end gap-1"><label className="text-[10px] text-gray-500 uppercase">Stock Level</label><input type="number" value={inventory[p.id] ?? 0} onChange={(e) => updateStock(p.id, parseInt(e.target.value))} className="w-16 bg-white/5 border border-white/10 rounded px-2 py-1 text-sm text-center text-white focus:border-brand-accent outline-none transition-colors" /></div>
                                    </div>
                                    <div className="flex items-center gap-4 mt-3 pt-2 border-t border-white/5">
                                        <div className="flex items-center gap-2"><span className="text-xs text-gray-500">Price $</span><input type="number" value={p.price} onChange={(e) => updatePrice(p.id, parseFloat(e.target.value))} className="w-16 bg-transparent border-b border-white/20 px-1 py-0.5 text-sm text-white focus:border-brand-accent outline-none" /></div>
                                        <button onClick={() => { setEditingPromo(editingPromo === p.id ? null : p.id); setPromoData(p.promo ? { ...p.promo } : { buyQuantity: 2, price: p.price * 2 * 0.9, label: '2 for $...' }); }} className={`ml-auto text-xs px-2 py-1 rounded border ${p.promo ? 'border-brand-accent text-brand-accent' : 'border-white/10 text-gray-400'} hover:bg-white/5`}><Percent size={12} className="inline mr-1"/> {p.promo ? 'Edit Promo' : 'Add Promo'}</button>
                                    </div>
                                    {editingPromo === p.id && (
                                        <div className="mt-3 bg-brand-accent/10 p-3 rounded border border-brand-accent/30 animate-fade-in">
                                            <div className="flex gap-2 mb-2">
                                                <div className="flex-1"><label className="text-[10px] text-brand-accent block">Buy Qty</label><input type="number" className="w-full bg-black/50 border border-brand-accent/30 rounded px-2 py-1 text-xs text-white" value={promoData.buyQuantity} onChange={e => setPromoData({...promoData, buyQuantity: parseInt(e.target.value)})} /></div>
                                                <div className="flex-1"><label className="text-[10px] text-brand-accent block">Bundle Price</label><input type="number" className="w-full bg-black/50 border border-brand-accent/30 rounded px-2 py-1 text-xs text-white" value={promoData.price} onChange={e => setPromoData({...promoData, price: parseFloat(e.target.value)})} /></div>
                                            </div>
                                            <div className="mb-2"><label className="text-[10px] text-brand-accent block">Label</label><input type="text" className="w-full bg-black/50 border border-brand-accent/30 rounded px-2 py-1 text-xs text-white" value={promoData.label} onChange={e => setPromoData({...promoData, label: e.target.value})} /></div>
                                            <div className="flex gap-2"><button onClick={() => savePromo(p.id)} className="flex-1 bg-brand-accent text-white text-xs font-bold py-1 rounded">Save</button>{p.promo && <button onClick={() => updatePromo(p.id, undefined)} className="flex-1 border border-red-500 text-red-500 text-xs font-bold py-1 rounded hover:bg-red-500/10">Remove</button>}</div>
                                        </div>
                                    )}
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="col-span-1 md:col-span-2 flex flex-wrap justify-between items-center bg-zinc-900 border border-white/10 p-4 rounded-xl">
                         <div className="flex items-center gap-4"><span className="text-gray-400 text-sm font-bold">Time Period:</span><div className="flex bg-black/30 rounded-lg p-1">{['daily', 'weekly', 'monthly'].map((range) => (<button key={range} onClick={() => setDateRange(range as any)} className={`px-4 py-1.5 rounded-md text-xs font-bold capitalize transition-all ${dateRange === range ? 'bg-white text-black' : 'text-gray-400 hover:text-white'}`}>{range}</button>))}</div></div>
                         <div className="flex items-center gap-2 mt-4 md:mt-0"><span className="text-gray-400 text-sm">Sort Products By:</span><select value={sortSalesBy} onChange={(e) => setSortSalesBy(e.target.value as any)} className="bg-black/30 border border-white/10 rounded px-3 py-1.5 text-sm text-white focus:border-brand-accent outline-none"><option value="revenue">Total Revenue</option><option value="quantity">Units Sold</option></select></div>
                    </div>
                    <div className="bg-zinc-900 border border-white/10 rounded-xl p-6 col-span-1 md:col-span-2">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><TrendingUp /> Sales by Product ({dateRange})</h2>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-white/5 uppercase text-xs text-gray-400"><tr><th className="px-4 py-3 rounded-tl-lg">Product Name</th><th className="px-4 py-3 text-right">Units Sold</th><th className="px-4 py-3 rounded-tr-lg text-right">Revenue</th></tr></thead>
                                <tbody className="divide-y divide-white/10">{salesReport.productStats.length === 0 ? (<tr><td colSpan={3} className="px-4 py-4 text-center text-gray-500">No sales data for this period.</td></tr>) : (salesReport.productStats.map((stat, i) => (<tr key={i} className="hover:bg-white/5 transition-colors"><td className="px-4 py-3 font-medium text-white">{stat.name}</td><td className="px-4 py-3 text-right text-gray-300">{stat.quantity}</td><td className="px-4 py-3 text-right text-brand-success font-bold">${stat.revenue.toFixed(2)}</td></tr>)))}</tbody>
                            </table>
                        </div>
                    </div>
                    <div className="bg-zinc-900 border border-white/10 rounded-xl p-6">
                        <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2"><PieChart /> Revenue by Payment Method</h2>
                        <div className="space-y-4">{Object.entries(salesReport.paymentStats).map(([method, amount]) => (<div key={method} className="flex items-center justify-between bg-black/30 p-4 rounded-lg"><div className="flex items-center gap-3"><div className="p-2 bg-brand-accent/20 rounded-full text-brand-accent"><DollarSign size={16} /></div><span className="font-bold text-white capitalize">{method === 'cashapp' ? 'Cash App' : method}</span></div><span className="text-xl font-bold text-white">${amount.toFixed(2)}</span></div>))}<div className="pt-4 mt-4 border-t border-white/10 flex justify-between items-center"><span className="font-bold text-gray-400">Total Revenue</span><span className="text-2xl font-bold text-brand-success">${salesReport.totalRevenue.toFixed(2)}</span></div></div>
                    </div>
                </div>
            )}
        </div>
    );
};

// --- MAIN APP COMPONENT ---

const App = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [inventory, setInventory] = useState<Record<string, number>>(() => { const inv: Record<string, number> = {}; PRODUCTS.forEach(p => inv[p.id] = p.stock); return inv; });
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [orders, setOrders] = useState<Order[]>([]);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [pendingOrderDetails, setPendingOrderDetails] = useState<any>(null);

  const addToCart = (product: Product, quantity: number) => { if (inventory[product.id] < quantity) return; setCart(prev => { const existing = prev.find(item => item.id === product.id); if (existing) { return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item); } return [...prev, { ...product, quantity }]; }); setIsCartOpen(true); };
  const removeFromCart = (id: string) => { setCart(prev => prev.filter(item => item.id !== id)); };
  const updateQuantity = (id: string, delta: number) => { setCart(prev => prev.map(item => { if (item.id === id) { const newQty = item.quantity + delta; if (newQty <= 0) return item; if (newQty > inventory[id]) return item; return { ...item, quantity: newQty }; } return item; })); };
  const handleCheckoutStart = (details: any) => { if (!user) { alert("Please login to checkout"); return; } setPendingOrderDetails(details); setPaymentModalOpen(true); setIsCartOpen(false); };
  const handlePaymentConfirm = (method: string) => { if (!pendingOrderDetails || !user) return; const newOrder: Order = { id: Math.random().toString(36).substr(2, 9), userId: user.id, items: [...cart], total: pendingOrderDetails.total, status: 'Pending', date: new Date().toISOString(), deliveryMethod: pendingOrderDetails.deliveryMethod, deliveryInstructions: pendingOrderDetails.instructions, paymentMethod: method, customerAddress: "123 Test St (Simulated)", estimatedDeliveryTime: "Pending Approval" }; const newInventory = { ...inventory }; cart.forEach(item => { if (newInventory[item.id] >= item.quantity) { newInventory[item.id] -= item.quantity; } }); setInventory(newInventory); setOrders(prev => [newOrder, ...prev]); sendOrderConfirmationEmail(newOrder, user); sendNotification('Admin', `New Order #${newOrder.id.slice(0,5)} received! ($${newOrder.total.toFixed(2)})`); setCart([]); setPaymentModalOpen(false); setPendingOrderDetails(null); };
  const handleReorder = (order: Order) => { let addedCount = 0; const missingItems: string[] = []; setCart(prev => { const newCart = [...prev]; order.items.forEach(item => { const currentStock = inventory[item.id] || 0; const inCart = newCart.find(c => c.id === item.id); const currentQty = inCart ? inCart.quantity : 0; if (currentStock >= currentQty + item.quantity) { if (inCart) { inCart.quantity += item.quantity; } else { newCart.push({ ...item }); } addedCount++; } else { missingItems.push(item.name); } }); return newCart; }); if (addedCount > 0) setIsCartOpen(true); if (missingItems.length > 0) { alert(`Some items could not be reordered due to limited stock: ${missingItems.join(', ')}`); } };
  const handleLogin = (email: string, pass: string) => { const role = email.includes('admin') ? 'admin' : 'customer'; setUser({ id: 'u1', name: email.split('@')[0], email, role }); };
  const handleSignup = (name: string, email: string, pass: string) => { setUser({ id: 'u2', name, email, role: 'customer' }); };
  const handleLogout = () => { setUser(null); setCart([]); };
  const handleUpdateStock = (productId: string, newValue: number) => { setInventory(prev => ({ ...prev, [productId]: Math.max(0, newValue) })); };
  const handleUpdatePrice = (productId: string, newPrice: number) => { setProducts(prev => prev.map(p => p.id === productId ? { ...p, price: newPrice } : p)); };
  const handleAddProduct = (newProductData: any) => { const newId = `p${Math.random().toString(36).substr(2, 6)}`; const product: Product = { ...newProductData, id: newId }; setProducts(prev => [...prev, product]); setInventory(prev => ({ ...prev, [newId]: newProductData.stock })); };
  const handleUpdatePromo = (productId: string, promo: any) => { setProducts(prev => prev.map(p => p.id === productId ? { ...p, promo } : p)); };

  const handleUpdateOrderStatus = (orderId: string, status: 'Pending' | 'Accepted' | 'Delivering' | 'Completed') => {
      setOrders(prev => {
          let updatedOrders = prev.map(o => o.id === orderId ? { ...o, status } : o);
          const order = prev.find(o => o.id === orderId);
          if (order) {
              if (status === 'Accepted') sendNotification('Customer', `Order #${order.id.slice(0,5)} Accepted! Preparing now.`);
              if (status === 'Delivering') sendNotification('Customer', `Order #${order.id.slice(0,5)} is Out for Delivery! Track it live.`);
              if (status === 'Completed') sendNotification('Customer', `Order #${order.id.slice(0,5)} Delivered. Enjoy!`);
          }
          
          // AI Route Optimization Simulation
          if (status === 'Accepted') {
              console.log("🤖 AI Agent: Optimizing Delivery Route...");
              const activeCount = updatedOrders.filter(o => o.status === 'Accepted' || o.status === 'Delivering').length;
              const baseTime = 15; // Base delivery time in mins
              
              updatedOrders = updatedOrders.map(o => {
                  if (o.status === 'Accepted' || o.status === 'Delivering') {
                       // Add 5 mins for each active order in queue to simulate routing delay
                       // Random variation for "traffic"
                       const traffic = Math.floor(Math.random() * 8); 
                       const queueDelay = (activeCount - 1) * 5; 
                       const newEstimate = baseTime + queueDelay + traffic;
                       
                       return {
                           ...o,
                           estimatedDeliveryTime: `${newEstimate}-${newEstimate + 10} mins`
                       };
                  }
                  return o;
              });
          }
          return updatedOrders;
      });
  };

  return (
    <HashRouter>
      <div className="bg-brand-dark min-h-screen text-white font-sans selection:bg-brand-accent selection:text-white flex flex-col">
        <Navbar cartCount={cart.reduce((a, b) => a + b.quantity, 0)} toggleCart={() => setIsCartOpen(!isCartOpen)} mobileMenuOpen={mobileMenuOpen} setMobileMenuOpen={setMobileMenuOpen} user={user} onLogout={handleLogout} />
        <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} cart={cart} updateQuantity={updateQuantity} removeFromCart={removeFromCart} onCheckoutStart={handleCheckoutStart} />
        <PaymentModal isOpen={paymentModalOpen} onClose={() => setPaymentModalOpen(false)} total={pendingOrderDetails?.total || 0} onConfirm={handlePaymentConfirm} />
        
        <div className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/menu" element={<MenuPage addToCart={addToCart} inventory={inventory} products={products} />} />
            <Route path="/delivery" element={<DeliveryCheckPage />} />
            <Route path="/track/:orderId" element={user ? <OrderTrackingPage orders={orders} user={user} /> : <Navigate to="/login" />} />
            <Route path="/login" element={<LoginPage onLogin={handleLogin} onSignup={handleSignup} />} />
            <Route path="/orders" element={user ? <OrdersPage orders={orders} user={user} onReorder={handleReorder} /> : <Navigate to="/login" />} />
            <Route path="/admin" element={user?.role === 'admin' ? <AdminDashboard inventory={inventory} orders={orders} updateStock={handleUpdateStock} updateOrderStatus={handleUpdateOrderStatus} products={products} updatePrice={handleUpdatePrice} addProduct={handleAddProduct} updatePromo={handleUpdatePromo} /> : <Navigate to="/" />} />
          </Routes>
        </div>

        <Footer />
      </div>
    </HashRouter>
  );
};

export default App;